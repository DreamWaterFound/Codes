# neu robot bringup package

二驱四轮小车的驱动节点。

----

开发日志：

 - 2019.08.02 15.01 生成ROS节点
 - 